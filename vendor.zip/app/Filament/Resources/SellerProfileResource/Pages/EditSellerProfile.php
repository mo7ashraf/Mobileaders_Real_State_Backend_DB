<?php

namespace App\Filament\Resources\SellerProfileResource\Pages;

use App\Filament\Resources\SellerProfileResource;
use Filament\Resources\Pages\EditRecord;

class EditSellerProfile extends EditRecord
{
    protected static string $resource = SellerProfileResource::class;
}

