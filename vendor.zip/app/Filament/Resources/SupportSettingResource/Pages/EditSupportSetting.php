<?php

namespace App\Filament\Resources\SupportSettingResource\Pages;

use App\Filament\Resources\SupportSettingResource;
use Filament\Resources\Pages\EditRecord;

class EditSupportSetting extends EditRecord
{
    protected static string $resource = SupportSettingResource::class;
}

