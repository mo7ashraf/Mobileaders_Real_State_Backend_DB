<?php

namespace App\Filament\Resources\SupportSettingResource\Pages;

use App\Filament\Resources\SupportSettingResource;
use Filament\Resources\Pages\CreateRecord;

class CreateSupportSetting extends CreateRecord
{
    protected static string $resource = SupportSettingResource::class;
}

