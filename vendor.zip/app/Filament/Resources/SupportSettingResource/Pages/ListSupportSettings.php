<?php

namespace App\Filament\Resources\SupportSettingResource\Pages;

use App\Filament\Resources\SupportSettingResource;
use Filament\Resources\Pages\ListRecords;

class ListSupportSettings extends ListRecords
{
    protected static string $resource = SupportSettingResource::class;
}

