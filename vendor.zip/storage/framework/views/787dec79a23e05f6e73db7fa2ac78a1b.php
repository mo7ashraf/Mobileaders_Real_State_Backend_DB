<div <?php echo e($attributes->class(['fi-dropdown-list p-1'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH D:\Appscoper\Flutter\realestate_starter_v2\backend_app\realestate-api\vendor\filament\support\resources\views/components/dropdown/list/index.blade.php ENDPATH**/ ?>