@extends('web.layout')
@section('title','Ping')
@section('content')
  <div class="bg-white rounded-2xl shadow p-6 text-center">OK</div>
@endsection

